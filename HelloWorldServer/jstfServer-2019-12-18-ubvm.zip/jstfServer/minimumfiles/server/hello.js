let message = "Hello, World!";
console.log(message);

